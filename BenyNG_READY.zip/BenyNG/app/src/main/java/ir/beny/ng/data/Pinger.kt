package ir.beny.ng.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

object Pinger {
    /** زمان اتصال TCP به سرور به میلی‌ثانیه؛ -2 یعنی پاسخ نداد. */
    suspend fun tcp(host: String, port: Int, timeoutMs: Int = 3000): Int = withContext(Dispatchers.IO) {
        try {
            val start = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
            ((System.nanoTime() - start) / 1_000_000).toInt().coerceAtLeast(1)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            -2
        }
    }
}
