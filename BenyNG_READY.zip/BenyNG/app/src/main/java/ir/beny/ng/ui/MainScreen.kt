package ir.beny.ng.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.beny.ng.data.Server

@Composable
fun MainScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var showAdd by remember { mutableStateOf(false) }
    var showSubs by remember { mutableStateOf(false) }

    LaunchedEffect(vm.message) {
        vm.message?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_LONG).show()
            vm.message = null
        }
    }

    GlassBackground {
        val list = vm.sortedServers()
        LazyColumn(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { Header(vm, onAdd = { showAdd = true }, onSubs = { showSubs = true }) }
            item { ConnectCard(vm) }
            item { Actions(vm) }
            item { if (vm.busy || vm.testing) LinearProgressIndicator(Modifier.fillMaxWidth()) }
            vm.clipUrl?.let { url ->
                item {
                    ClipBanner(url, onAdd = { vm.addSubscription(url); vm.clipUrl = null }, onClose = { vm.clipUrl = null })
                }
            }
            if (list.isEmpty()) item { EmptyHint() }
            items(list, key = { it.id }) { s -> ServerRow(vm, s) }
        }
    }

    if (showAdd) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("افزودن کانفیگ یا اشتراک") },
            text = {
                OutlinedTextField(
                    text, { text = it }, Modifier.fillMaxWidth(), minLines = 3,
                    placeholder = { Text("لینک vless:// vmess:// trojan:// ss:// یا لینک اشتراک") },
                )
            },
            confirmButton = { TextButton(onClick = { vm.addFromInput(text); showAdd = false }) { Text("افزودن") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("انصراف") } },
        )
    }

    if (showSubs) {
        AlertDialog(
            onDismissRequest = { showSubs = false },
            title = { Text("اشتراک‌ها") },
            text = {
                Column {
                    if (vm.subs.isEmpty()) Text("اشتراکی نیست. لینک اشتراک را با + اضافه کن.")
                    vm.subs.forEach { s ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(s.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            IconButton(onClick = { vm.deleteSub(s.id) }) { Icon(Icons.Default.Delete, "حذف") }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.refreshSubs(); showSubs = false }) { Text("به‌روزرسانی همه") } },
            dismissButton = { TextButton(onClick = { showSubs = false }) { Text("بستن") } },
        )
    }
}

@Composable
private fun Header(vm: MainViewModel, onAdd: () -> Unit, onSubs: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Beny NG", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("${vm.servers.size} سرور", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        }
        IconButton(onClick = onSubs) { Icon(Icons.Default.Menu, "اشتراک‌ها", tint = Color.White) }
        IconButton(onClick = onAdd) { Icon(Icons.Default.Add, "افزودن", tint = Color.White) }
    }
}

@Composable
private fun ConnectCard(vm: MainViewModel) {
    GlassCard(Modifier.fillMaxWidth(), corner = 28.dp) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(120.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0x597DF9FF), Color(0x407C5CFF))))
                    .border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                    .clickable { vm.connect() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Default.PlayArrow, "اتصال", tint = Color.White, modifier = Modifier.size(56.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text("متصل نیست", color = Color.White, fontWeight = FontWeight.SemiBold)
            val sel = vm.servers.firstOrNull { it.id == vm.selectedId }
            val ping = sel?.let { vm.pings[it.id] }
            Text(
                if (sel == null) "سروری انتخاب نشده"
                else sel.name + if (ping != null && ping > 0) " · $ping ms" else "",
                color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = TextStyle(textDirection = TextDirection.Content),
            )
        }
    }
}

@Composable
private fun Actions(vm: MainViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("تست پینگ همه", Modifier.weight(1f), enabled = !vm.testing) { vm.testAll() }
            GlassButton("بهترین سرور", Modifier.weight(1f), enabled = !vm.testing) { vm.testAll(thenPick = true) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("انتخاب خودکار بهترین بعد از هر تست", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, modifier = Modifier.weight(1f))
            Switch(checked = vm.autoSelect, onCheckedChange = { vm.setAutoSelect(it) })
        }
    }
}

@Composable
private fun ClipBanner(url: String, onAdd: () -> Unit, onClose: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("یک لینک در کلیپ‌بورد پیدا شد. اشتراک است؟", color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(url, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = TextStyle(textDirection = TextDirection.Ltr))
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("افزودن اشتراک", Modifier.weight(1f), onClick = onAdd)
                GlassButton("نه", Modifier.weight(1f), onClick = onClose)
            }
        }
    }
}

@Composable
private fun EmptyHint() {
    GlassCard(Modifier.fillMaxWidth()) {
        Text(
            "هنوز سروری نیست. لینک کانفیگ (vless / vmess / trojan / ss) را کپی کن و برنامه را باز کن؛ خودش تشخیص می‌دهد. یا دکمه‌ی + را بزن.",
            Modifier.padding(16.dp), color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp,
        )
    }
}

@Composable
private fun PingBadge(p: Int?) {
    val (text, color) = when {
        p == null -> "—" to Color(0xFF9AA4B2)
        p <= 0 -> "✕" to Color(0xFFFF6B6B)
        p < 300 -> "$p ms" to Color(0xFF4ADE80)
        p < 800 -> "$p ms" to Color(0xFFFACC15)
        else -> "$p ms" to Color(0xFFFB923C)
    }
    Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
}

@Composable
private fun ServerRow(vm: MainViewModel, s: Server) {
    GlassCard(Modifier.fillMaxWidth(), selected = s.id == vm.selectedId, onClick = { vm.select(s.id) }) {
        Row(Modifier.padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    s.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = TextStyle(textDirection = TextDirection.Content),
                )
                Text(
                    "${s.protocol.uppercase()} · ${s.host}:${s.port}", color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Ltr),
                )
            }
            PingBadge(vm.pings[s.id])
            IconButton(onClick = { vm.delete(s.id) }) { Icon(Icons.Default.Delete, "حذف", tint = Color.White.copy(alpha = 0.6f)) }
        }
    }
}
