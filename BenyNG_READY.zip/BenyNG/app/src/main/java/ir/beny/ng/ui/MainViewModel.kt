package ir.beny.ng.ui

import android.app.Application
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.beny.ng.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.net.URI
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    val servers = mutableStateListOf<Server>().apply { addAll(store.loadServers()) }
    val subs = mutableStateListOf<Sub>().apply { addAll(store.loadSubs()) }
    val pings = mutableStateMapOf<String, Int>()

    var selectedId by mutableStateOf(store.selectedId)
    var autoSelect by mutableStateOf(store.autoSelect)
    var testing by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var clipUrl by mutableStateOf<String?>(null)

    private var lastClip = store.lastClip

    init {
        if (subs.isNotEmpty()) refreshSubs()
    }

    fun sortedServers(): List<Server> {
        if (pings.isEmpty()) return servers.toList()
        return servers.sortedBy { s ->
            val p = pings[s.id]
            when {
                p == null -> Int.MAX_VALUE - 1
                p > 0 -> p
                else -> Int.MAX_VALUE
            }
        }
    }

    fun select(id: String) {
        selectedId = id
        store.selectedId = id
    }

    fun setAutoSelect(v: Boolean) {
        autoSelect = v
        store.autoSelect = v
    }

    fun connect() {
        message = "اتصال VPN در مرحله‌ی بعد اضافه می‌شود. فعلاً سرور وارد کن، تست کن و بهترین را انتخاب کن."
    }

    // ---------- ورود کانفیگ ----------
    fun checkClipboard(ctx: Context) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0)
            clip.getItemAt(0).coerceToText(ctx)?.toString()?.trim().orEmpty() else ""
        if (text.isBlank() || text == lastClip) return
        lastClip = text
        store.lastClip = text
        if (LinkParser.extractLinks(text).isNotEmpty()) {
            importText(text)
        } else if (Regex("^https?://\\S+$").matches(text)) {
            clipUrl = text
        }
    }

    fun addFromInput(text: String) {
        val t = text.trim()
        when {
            LinkParser.extractLinks(t).isNotEmpty() -> importText(t)
            t.startsWith("http://") || t.startsWith("https://") -> addSubscription(t)
            else -> message = "چیزی برای افزودن پیدا نشد"
        }
    }

    fun importText(text: String, group: String = ""): Int {
        val parsed = LinkParser.extractLinks(text).mapNotNull { LinkParser.parse(it) }
            .map { if (group.isNotBlank()) it.copy(group = group) else it }
        val existing = servers.map { it.id }.toSet()
        val fresh = parsed.filter { it.id !in existing }.distinctBy { it.id }
        if (fresh.isNotEmpty()) {
            servers.addAll(fresh)
            store.saveServers(servers)
            if (selectedId == null) select(fresh.first().id)
            message = "${fresh.size} کانفیگ اضافه شد"
        } else {
            message = if (parsed.isEmpty()) "کانفیگ معتبری پیدا نشد" else "این کانفیگ‌ها قبلاً اضافه شده‌اند"
        }
        return fresh.size
    }

    private fun replaceGroup(group: String, list: List<Server>) {
        servers.removeAll { it.group == group }
        servers.addAll(list.map { it.copy(group = group) })
        if (selectedId != null && servers.none { it.id == selectedId }) {\n            selectedId = servers.firstOrNull()?.id\n            store.selectedId = selectedId\n        }
        store.saveServers(servers)
    }

    // ---------- اشتراک ----------
    fun addSubscription(url: String) {
        viewModelScope.launch {
            busy = true
            try {
                val list = Subscription.parse(Subscription.fetch(url))
                if (list.isEmpty()) {
                    message = "در این لینک کانفیگی پیدا نشد"
                } else {
                    val name = try { URI(url).host } catch (e: Exception) { null } ?: "اشتراک"
                    val sub = subs.firstOrNull { it.url == url }
                        ?: Sub(UUID.randomUUID().toString(), name, url).also { subs.add(it) }
                    store.saveSubs(subs)
                    replaceGroup(sub.id, list)
                    if (selectedId == null) selectedId = servers.firstOrNull()?.id
                    message = "${list.size} کانفیگ از اشتراک اضافه شد"
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "دریافت اشتراک ناموفق بود: ${e.message}"
            } finally {
                busy = false
            }
        }
    }

    fun refreshSubs() {
        if (subs.isEmpty()) {
            message = "اشتراکی اضافه نشده"
            return
        }
        viewModelScope.launch {
            busy = true
            var ok = 0
            for (sub in subs.toList()) {
                try {
                    val list = Subscription.parse(Subscription.fetch(sub.url))
                    if (list.isNotEmpty()) {
                        replaceGroup(sub.id, list)
                        ok++
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                }
            }
            busy = false
            message = "$ok اشتراک به‌روز شد"
        }
    }

    fun deleteSub(id: String) {
        subs.removeAll { it.id == id }
        store.saveSubs(subs)
        servers.removeAll { it.group == id }
        if (selectedId != null && servers.none { it.id == selectedId }) {\n            selectedId = servers.firstOrNull()?.id\n            store.selectedId = selectedId\n        }
        store.saveServers(servers)
    }

    fun delete(id: String) {
        servers.removeAll { it.id == id }
        pings.remove(id)
        if (selectedId == id) selectedId = servers.firstOrNull()?.id
        store.selectedId = selectedId
        store.saveServers(servers)
    }

    // ---------- پینگ و انتخاب خودکار ----------
    fun testAll(thenPick: Boolean = false) {
        if (testing) return
        val snapshot = servers.toList()
        if (snapshot.isEmpty()) {
            message = "اول کانفیگ اضافه کن"
            return
        }
        testing = true
        pings.clear()
        viewModelScope.launch {
            try {
                val sem = Semaphore(24)
                snapshot.map { s ->
                    async { sem.withPermit { pings[s.id] = Pinger.tcp(s.host, s.port) } }
                }.awaitAll()
                if (thenPick || autoSelect) pickFastest()
            } finally {
                testing = false
            }
        }
    }

    fun pickFastest() {
        val best = servers.filter { (pings[it.id] ?: -1) > 0 }.minByOrNull { pings[it.id]!! }
        if (best != null) {
            select(best.id)
            message = "بهترین سرور: ${best.name} (${pings[best.id]} ms)"
        } else {
            message = "هیچ سروری پاسخ نداد"
        }
    }
}
