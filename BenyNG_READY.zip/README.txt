Beny NG - Ready Build Package

This package contains the current standalone Beny NG Android project plus a clean GitHub Actions workflow.

Build:
1. Upload the BenyNG folder to a GitHub repository.
2. Make sure .github/workflows/beny.yml is on the default branch.
3. Open Actions -> Beny NG Build -> Run workflow.
4. After a green build, download the BenyNG-apk artifact.

Important:
This package is the standalone Beny NG app from the supplied project. It does NOT contain the full v2rayNG/Xray VPN core. Its current connect action is UI-only, as documented in BenyNG/README_FIXES.md.
No keystore or Decode Keystore step is used in this workflow.
